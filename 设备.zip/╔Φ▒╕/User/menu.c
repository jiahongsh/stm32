#include "menu.h" 
#include "menu_test.h"
#include <string.h>
#include "Makey.h"
#include "LED.h"
#include "OLED.h"
#include "Buzzer.h"
#include "Delay.h"
#define PNEC_Water_A  570
#define PNEC_Solid_A  2060
#define PNEC_Soil_A   190
#define PNEC_Water_S  1
#define PNEC_Solid_S  3
#define PNEC_Soil_S   1
/**********************************************************/
uint8_t KeyNum;
uint32_t Count;
char*a="ng/L";
char*b="ng/kg";
void Init(){
   OLED_Init();
   Buzzer_Init();
   MatrixKey_Init();
   LED_Init();
}
void function(int PNEC,char*p){
    Init();
	//OLED_Clear();
	KeyNum=0;
	Count=0;
	OLED_ShowString(1, 1, "KeyNum:",OLED_8X16);
	LED_OFF(GPIO_Pin_11);
	OLED_ShowString(1, 32, "Rank:",OLED_8X16);
	OLED_ShowString(88,15,p,OLED_8X16);    
    OLED_ShowHexNum(24,16,0X00,8,OLED_8X16);  
    //Buzzer_ON(GPIO_Pin_12);	
	while (1)             
	{   
		
		KeyNum = MatrixKey_GetValue();
		 //OLED_ShowNum(1, 9, KeyNum, 2); 
		if(Count>999999999) {
			 Count=0;
		}
		if(KeyNum==8)  //0
	    {
         Count=Count*10;          
         OLED_ShowNum(24,16,Count,8,OLED_8X16); 
         while(KeyNum==8){
			  KeyNum = MatrixKey_GetValue();
		 }
		}
		else if(KeyNum==3) //1
	    {  
			Count=Count*10+1;
           OLED_ShowNum(24,16,Count,8,OLED_8X16);                     
		   while(KeyNum==3)
		   {
			  KeyNum = MatrixKey_GetValue();
		   };
	    }
		else if(KeyNum==7)  //2
	    {
         Count=Count*10+2;          
         OLED_ShowNum(24,16,Count,8,OLED_8X16); 
         while(KeyNum==7){
			  KeyNum = MatrixKey_GetValue();
		 };

	    }
		else if(KeyNum==11) //3
	    {
		 Count=Count*10+3;               
         OLED_ShowNum(24,16,Count,8,OLED_8X16); 
         while(KeyNum==11){
			  KeyNum = MatrixKey_GetValue();
		}	
       }   
	    else if(KeyNum==2) //4
	    {
		 Count=Count*10+4;
         OLED_ShowNum(24,16,Count,8,OLED_8X16); 
         while(KeyNum==2){            
			 KeyNum = MatrixKey_GetValue();
		}	
       }  
	    else if(KeyNum==6) //5
	    {
		 Count=Count*10+5;
         OLED_ShowNum(24,16,Count,8,OLED_8X16); 
         while(KeyNum==6){
			  KeyNum = MatrixKey_GetValue();   
		}	
       }
       else if(KeyNum==10)// 6
	    {
		 Count=Count*10+6;
         OLED_ShowNum(24,16,Count,8,OLED_8X16); 
         while(KeyNum==10){        
			  KeyNum = MatrixKey_GetValue();
		}	
       }
	   else if(KeyNum==1)  //7
	    {
		 Count=Count*10+7;
         OLED_ShowNum(24,16,Count,8,OLED_8X16); 
         while(KeyNum==1){
			   KeyNum = MatrixKey_GetValue();
		}	
       }
	   else if(KeyNum==5)  //8             
	    {
		 Count=Count*10+8;
         OLED_ShowNum(24,16,Count,8,OLED_8X16); 
         while(KeyNum==5){
			  KeyNum = MatrixKey_GetValue();
		}	
       }
	   else if(KeyNum==9)    //9
	    {
		 Count=Count*10+9;
         OLED_ShowNum(24,16,Count,8,OLED_8X16); 
         while(KeyNum==9){
			   KeyNum = MatrixKey_GetValue();
		}	
       }
	   else if(KeyNum==15)   //删除
	    {
		 Count=Count/10;
         OLED_ShowNum(24,16,Count,8,OLED_8X16); 
         while(KeyNum==15){
			   KeyNum = MatrixKey_GetValue();
		}	
       }   
		
	    else if(KeyNum==13)   //确认键
	    {
			uint16_t RQ=Count/PNEC;
		   if(Count/PNEC_Water_A>=1000)
			{
			   //OLED_ShowString(2, 1, "Rank:");
			   OLED_ShowString(40,48,"          ",OLED_8X16);
			   OLED_ShowString(40,48,"High Risk",OLED_8X16);
               LED_ON( GPIO_Pin_11);
			   Buzzer_ON(GPIO_Pin_12);
			   KeyNum = MatrixKey_GetValue();
				if(KeyNum==14)
				{
				  LED_OFF(GPIO_Pin_11);
				  Buzzer_OFF(GPIO_Pin_12);
				  break;	
				}
	        }
		   if(Count/PNEC_Water_A<1000&&Count/PNEC_Water_A>=100)
			{
			   uint16_t i=10;
			 // OLED_ShowString(2, 1, "Rank:");
			  OLED_ShowString(40,48,"           ",OLED_8X16);
			  OLED_ShowString(40,48,"Middle Risk",OLED_8X16); 
			   while(i--)
			   {
				
			    LED_ON( GPIO_Pin_11);
                Delay_ms(50);			   
			    LED_OFF(GPIO_Pin_11);
                Delay_ms(50);			
		       }   
			}
		   if(Count/PNEC_Water_A<100&&Count/PNEC_Water_A>=10)
		   {
			   uint16_t i=10;
			  // OLED_ShowString(2, 1, "Rank:");
			   OLED_ShowString(40,48,"          ",OLED_8X16);
			   OLED_ShowString(40,48,"Low Risk",OLED_8X16);
			   while(i--)
			   {  
			    LED_ON( GPIO_Pin_11);
                Delay_ms(200);
                LED_OFF(GPIO_Pin_11);
                Delay_ms(200);
			  }  
		   }
		   if(Count/PNEC_Water_A<10)
			   { 
			   uint16_t i=10;
			  // OLED_ShowString(2, 1, "Rank:");
			   OLED_ShowString(40,48,"         ",OLED_8X16);
			   OLED_ShowString(40,48,"Stafety",OLED_8X16);
//			   while(i--)
//			   {
//			    LED_ON( GPIO_Pin_11);
//                Delay_ms(500);
//                LED_OFF(GPIO_Pin_11);
//                Delay_ms(500);
//			   }					
			 }	
//		   while(KeyNum==13)
//		   {
//			  KeyNum = MatrixKey_GetValue();
//		   }	
		}      
	    else if(KeyNum==14)    //停止蜂鸣器
	    {
		   LED_OFF(GPIO_Pin_11);
           Buzzer_OFF(GPIO_Pin_12);
           while(KeyNum==14)
	       {
			  KeyNum = MatrixKey_GetValue();
		   }	
        }    
		
       if(Key_Enter_Get()) {return;}
		
	   OLED_Update();
      }
	if(Key_Enter_Get()) {return;}
}

void P_W_S(){
	
	function(PNEC_Water_S,a);
}

void P_Solid_S(){
	
	
	function(PNEC_Solid_S,b);
}

void P_Soil_S(){  
	
	function(PNEC_Soil_S,b);
}

void P_W_A(){
	
	function(PNEC_Water_A,a);
}

void P_Solid_A(){
	
	function(PNEC_Solid_A,b);
}

void P_Soil_A(){
	
	function(PNEC_Solid_A,b);
}
void games_option(void)
{

	struct option_class option[] = {
		{"<<<"},
		{"PNEC_Water_S",P_W_S},	
		{"PNEC_Solid_S",P_Solid_S},		//6-6 输入捕获模式测频率
		{"PNEC_Soil_S",P_Soil_S},			//6-3 PWM驱动LED呼吸灯
		{".."}
	};
	
	run_play_option_class(option);
}

void tools_option(void)
{
	struct option_class option[] = {
		{"<<<"},
		{"PNEC_Water_A",P_W_A},	
		{"PNEC_Solid_A",P_Solid_A},		
		{"PNEC_Soil_A",P_Soil_A},			
		{".."}
	};
	
	run_play_option_class(option);
}



void main_menu(void)
{
	struct option_class option[] = {
		{"<<<"},
		{"PFOA", tools_option},
		{"PFOS",games_option},
		{"Setting", Setting},		//设置
		{"Information", Information},		//信息
		{".."}
	};
	
	run_play_option_class(option);
}

/**********************************************************/

void menu_Init(void)
{
	main_menu();
}	


void run_play_option_class(struct option_class* option)	//添加动画
{
	int8_t Catch_i = 1;		//选中下标
	int8_t Show_i = 0; 		//显示起始下标
	int8_t Cursor_i = 0;	//光标下标
	int8_t Max = 0;			//选项数量
	int8_t Incident = 0;	//编码器事件
	
	while(option[Max].Name[0] != '.') {Max++;}	//获取条目数量,如果文件名开头为'.'则为结尾;
	
	int8_t Speed = 8;																		//光标动画速度的倒数;
	static float Cursor_len_d0 = 0, Cursor_len_d1 = 0, Cursor_i_d0 = 0, Cursor_i_d1 = 0; 	//光标位置和长度的起点终点
	
	int8_t Show_d = 0, Show_i_temp = 6;			//显示动画相关;
	
	while(1)
	{
		OLED_Clear();
		
		Incident = Encoder_Get();		//获取按键事件//轮询;
		if(Incident)					//如果有按键事件;
		{
			Cursor_i += Incident;		//更新下标
			Catch_i += Incident;
			
			if(Catch_i < 0) {Catch_i = 0;}			//限制选中下标
			if(Catch_i > Max) {Catch_i = Max;}
			
			if(Cursor_i < 0) {Cursor_i = 0;}		//限制光标位置
			if(Cursor_i > 3) {Cursor_i = 3;}
			if(Cursor_i > Max) {Cursor_i = Max;}
		}
		
		/**********************************************************/
		/*显示相关*/
		
		Show_i = Catch_i - Cursor_i;				//计算显示起始下标
		
		if(1)		//加显示动画
		{
			if(Show_i - Show_i_temp)					//如果下标有偏移
			{
				Show_d = (Show_i - Show_i_temp) * WORD_H;	//
				Show_i_temp = Show_i;
			}
			if(Show_d) {Show_d /= 2;}				//变化量 1.26较平滑1.21
			
			/*如果菜单向下移动,Show_d = -16往0移动期间由于显示字符串函数不支持Y坐标为负数,跳过了打印,所以首行是空的,所以在首行打印Show_i - ((Show_d)/WORD_H)的选项名字,达到覆盖效果;((Show_d)/WORD_H)代替0,兼容Show_d <= -16的情况(菜单开始动画)*/
			if(Show_d < 0) {OLED_ShowString(2, 0, option[Show_i - ((Show_d)/WORD_H)].Name, OLED_8X16);}
			/*如果菜单向上移动,Show_d = 16往0移动期间首行是空的,所以在首行打印Show_i - 1的选项名字,达到覆盖效果;*/
			//if(Show_d > 0) {OLED_ShowString(2, 0, option[Show_i - 1].Name, OLED_8X16);}
		}
		for(int8_t i = 0; i < 6; i++)
		{	
			if(Show_i + i > Max ) {break;}			
			
			OLED_ShowString(2, (i* WORD_H)+Show_d, option[Show_i + i].Name, OLED_8X16);		//显示名字
			//OLED_DrawLine(0, (i* WORD_H)+Show_d+15, 96, (i* WORD_H)+Show_d+15);			//加行线
		}
		
		/**********************************************************/
		/*光标相关*/
		
		if(1)//加光标动画
		{
			Cursor_i_d1 = Cursor_i * WORD_H;					//轮询光标目标位置
			Cursor_len_d1 = strlen(option[Catch_i].Name) * 8 + 4;	//轮询光标目标宽度
			
			/*计算此次循环光标位置*/
			if((Cursor_i_d1 - Cursor_i_d0) > 1) {Cursor_i_d0 += (Cursor_i_d1 - Cursor_i_d0) / Speed + 1;}		//如果当前位置不是目标位置,当前位置向目标位置移动 它们之间距离乘速度的倒数;
			else if((Cursor_i_d1 - Cursor_i_d0) < -1) {Cursor_i_d0 += (Cursor_i_d1 - Cursor_i_d0) / Speed - 1;}
			else {Cursor_i_d0 = Cursor_i_d1;}
			
			/*计算此次循环光标宽度*/
			if((Cursor_len_d1 - Cursor_len_d0) > 1) {Cursor_len_d0 += (Cursor_len_d1 - Cursor_len_d0) / Speed + 1;}
			else if((Cursor_len_d1 - Cursor_len_d0) < -1) {Cursor_len_d0 += (Cursor_len_d1 - Cursor_len_d0) / Speed - 1;}
			else {Cursor_len_d0 = Cursor_len_d1;}
		}
		else {Cursor_i_d0 = Cursor_i * WORD_H; Cursor_len_d0 = 128;}
		
		//显示光标
		//OLED_DrawRectangle(0, Cursor_i_d0, Cursor_len_d0, 16, 0);			//矩形光标
		OLED_ReverseArea(0, Cursor_i_d0, Cursor_len_d0, WORD_H);			//反相光标
		//OLED_ShowString(Cursor_len_d0, Cursor_i_d0+6, "<-", OLED_6X8);	//尾巴光标
		
		/**********************************************************/
		
		if(Key_Enter_Get())		//获取按键
		{
			/*如果功能不为空则执行功能,否则返回*/
			if(option[Catch_i].func) {option[Catch_i].func();}
			else {return;}
		}
		
		OLED_ShowNum(116, 56, Catch_i, 2, OLED_6X8);		//右下角显示选中下标;
		OLED_Update();
	}
}

/**********************************************************/


