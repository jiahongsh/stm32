#ifndef __MATRIXKEY_H
#define __MATRIXKEY_H

void MatrixKey_Init();
uint8_t MatrixKey_GetValue();
uint8_t MatrixKey_determine();


#endif
