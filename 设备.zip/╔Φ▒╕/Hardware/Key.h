#ifndef __KEY_H
#define __KEY_H

void Key_Init(void);

int8_t Key_Enter_Get(void);

#endif
